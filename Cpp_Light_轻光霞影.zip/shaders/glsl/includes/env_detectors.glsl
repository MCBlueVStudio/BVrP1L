#ifndef _ENV_DETECTORS_GLSL
#define _ENV_DETECTORS_GLSL

// Include paths are resolved from shaders/glsl (shader root), never relative to
// the including file: "../xxx.h" or "xxx.glsl" inside a sub folder does NOT work
// in the NetEase OpenGL engine.
#include "uniformPerFrameConstants.h"
#include "uniformShaderConstants.h"

// Environment detectors that only read uniforms.
// They are safe to use in vertex shaders: no texture sampling here, because
// sampling inside a vertex shader is not supported on every OpenGL ES device.
// The texture based detectors (detectDay / detectHell / detectEnvironment)
// live in env_detectors_fragment.glsl and must only be used in fragment shaders.

float detectSunRize(){//TODO change detection method and move it to vertex shader
	float isSunrize = dot(normalize(FOG_COLOR.rgb), vec3(1.0, 0.0, 0.0));
	return pow(isSunrize, 4.0);
}

float detectRain(){
	float isRain = 0.5 - FOG_CONTROL.r;
    return clamp(isRain * 5.0, 0.0, 1.0);
}

float detectUnderwater(){
	if(FOG_CONTROL.r < 0.01)
	{
		return 1.0;
	}
	return 0.0;
}

#endif //_ENV_DETECTORS_GLSL
