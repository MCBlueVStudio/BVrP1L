#ifndef _TEXTURE_MAPPING_GLSL
#define _TEXTURE_MAPPING_GLSL

#include "uniformPerFrameConstants.h"
#include "uniformShaderConstants.h"

// texelFetch() only exists in GLSL ES 3.00. On GLSL ES 1.00 (OpenGL ES 2.0 and
// the OpenGL engine paths without ES 3.00 support) it has to be emulated with a
// regular texture read. Snapping the uv to the center of the nearest texel gives
// the same nearest-neighbour result as texelFetch(..., 0) and, unlike a plain
// texture2D(uv), never bleeds into the neighbouring tiles of the texture atlas.
#if __VERSION__ >= 300
#define ATLAS_TEXEL_FETCH(source, uv) texelFetch(source, ivec2((uv) * TEXTURE_DIMENSIONS.xy), 0)
#else
#define ATLAS_TEXEL_FETCH(source, uv) texture2D(source, (floor((uv) * TEXTURE_DIMENSIONS.xy) + vec2(0.5)) / TEXTURE_DIMENSIONS.xy)
#endif

    vec3 rotateNormals(vec3 baseNormal, vec3 reliefMap){
        // Fake TBN transformations for normalmapps
        // TODO: Weird thing and takes alot of performance because of branching
        // TODO: Needs refactoring
        if(length(reliefMap) > 0.9){
            
            float normalMapStrength = NORMAL_MAP_STRENGTH;

            if(baseNormal.g > 0.9){
                reliefMap.gb = reliefMap.bg;
                reliefMap = reliefMap * 2.0 - 1.0;
                reliefMap.rb *= normalMapStrength;
                baseNormal = normalize(reliefMap);
            }else{
                if(baseNormal.g < -0.9){
                    reliefMap.b = -reliefMap.b;
                    reliefMap.gb = reliefMap.bg;
                    reliefMap = reliefMap * 2.0 - 1.0;
                    reliefMap.rb *= normalMapStrength;
                    baseNormal = normalize(reliefMap);
                }else{
                    if (baseNormal.b > 0.9){
                        reliefMap.g = 1.0 - reliefMap.g;// OpenGl needs G to be flipped
                        reliefMap = reliefMap * 2.0 - 1.0;
                        reliefMap.rg *= normalMapStrength;
                        baseNormal = normalize(reliefMap);
        
                    }else{
                        if(baseNormal.b < -0.9){
                            reliefMap.b = -reliefMap.b;
                            reliefMap.g = 1.0 - reliefMap.g;// OpenGl G flip
                            reliefMap.r = 1.0 - reliefMap.r;
                            reliefMap.rg = reliefMap.rg * 2.0 - 1.0;
                            reliefMap.b = reliefMap.b * 2.0 + 1.0;
                            reliefMap.rg *= normalMapStrength;
                            baseNormal = normalize(reliefMap);
                        }else{
                            if(baseNormal.r > 0.9){
                                reliefMap.g = 1.0 - reliefMap.g;// OpenGl G flip
                                reliefMap.r = 1.0 - reliefMap.r;
                                reliefMap.rb = reliefMap.br;
                                reliefMap = reliefMap * 2.0 - 1.0;
                                reliefMap.gb *= normalMapStrength;
                                baseNormal = normalize(reliefMap);
                            }else{
                                if(baseNormal.r < -0.9){
                                    reliefMap.b = -reliefMap.b;
                                    reliefMap.g = 1.0 - reliefMap.g;//OpenGl G flip
                                    reliefMap.rb = reliefMap.br;
                                    reliefMap.gb = reliefMap.gb * 2.0 - 1.0;
                                    reliefMap.r = reliefMap.r * 2.0 + 1.0;
                                    reliefMap.gb *= normalMapStrength;
                                    baseNormal = normalize(reliefMap);
                                }
                            }
                        }
                    }
                }
            }
        }
        return baseNormal;
    }

    // Procedural water surface - single direction travelling waves.
    // 之前用的是值噪声（noise21）：它本质是「按格子插值」的噪声，转成法线以后
    // 格子边界会显形成一格一格的方块，而且固定在水面上随 TIME 自己动 —— 移动端
    // 精度更低时更明显。这里改成沿单一方向传播的行波，叠两三个非整数倍谐波保证
    // 不是等间距条纹，但不再有任何格纹。
    vec3 calculateWaterNormalVector(highp vec3 worldPosition){
		highp vec2 p = worldPosition.xz * WATER_WAVE_SCALE;
		highp float t = TIME * WATER_WAVE_SPEED;

		// 主传播方向（世界坐标），横向只留一点点扰动，避免出现"纵向叠加"
		highp vec2 dir = normalize(vec2(0.86, 0.51));
		highp vec2 side = vec2(-dir.y, dir.x);

		highp float along = dot(p, dir);
		highp float across = dot(p, side);

		highp float a1 = along * 1.15 - t * 0.85;
		highp float a2 = along * 2.45 - t * 1.30 + across * 0.95 + 2.1;
		highp float a3 = along * 5.10 - t * 1.95 + across * 2.20 + 5.3;

		highp float c1 = cos(a1);
		highp float c2 = cos(a2) * 0.45;
		highp float c3 = cos(a3) * 0.20;

		highp vec2 gradient = dir * (1.15 * c1 + 2.45 * c2 + 5.10 * c3)
		                    + side * (0.95 * c2 + 2.20 * c3);
		gradient *= 0.50; // 归一化到与之前相近的起伏幅度

		highp float strength = WATER_NORMAL_MAP_STRENGTH * 4.0;

		return normalize(vec3(-gradient.x * strength, 1.0, -gradient.y * strength));
    }

    // Procedural puddle mask.
    // Rounded, soft edged blobs in world space: continuous across chunk borders
    // (the old version used chunk local coordinates and the atlas noise, which is
    // what made the puddles look square and hard).
    float mapPuddles(highp vec2 worldXZ, float isRain){
		highp float n = fbm21(worldXZ / PUDDLES_SCALE);
		float mask = smoothstep(PUDDLES_THRESHOLD, PUDDLES_THRESHOLD + PUDDLES_SOFTNESS, n);
		mask = clamp(mask * PUDDLES_AMOUNT * isRain, 0.0, 1.0);

		return mask * pow(uv1.y, 2.0);// No puddles in dark places like caves
    }

    // Procedural underwater caustics (was another atlas cell read).
    float mapCaustics(highp vec3 worldPosition, float isUnderWater){
        if(isUnderWater < 0.5){
            return 0.0;
        }

        highp vec2 p = worldPosition.xz + vec2(worldPosition.y * 0.35);
        highp float t = TIME * 0.35;

        highp float caustics = 0.0;
        caustics += sin(dot(p, vec2(1.7, 1.1)) + t * 2.0);
        caustics += sin(dot(p, vec2(-1.2, 1.9)) - t * 1.7);
        caustics += sin(dot(p, vec2(0.8, -2.3)) + t * 2.4);

        caustics = clamp(caustics * (1.0 / 6.0) + 0.5, 0.0, 1.0);
        caustics = pow(caustics, 8.0);

        return caustics * 1.5;
    }


    void readTextures(out vec4 diffuseMap, out vec3 reliefMap, out vec4 rmeMap, sampler2D texture0, highp vec2 uv0){
        ////////////////////////////Mapping section///////////////////////////////////

        // every output is initialized, an output that is left untouched is
        // undefined in GLSL and shows up as garbage on some OpenGL drivers
        diffuseMap = vec4(1.0);
        reliefMap = vec3(0.0);
        rmeMap = vec4(0.0);

        #ifdef PBR_FEATURE_ENABLED
            // Top left texture - default diffuse
            highp vec2 diffuseMapCoord = fract(uv0 * TEXTURE_ATLAS_DIMENSION) / (TEXTURE_ATLAS_DIMENSION * 2.0);// 1.0 / 128.0 = 0.0078125; 1.0 / 64.0 = 0.015625
            diffuseMap = ATLAS_TEXEL_FETCH(texture0, uv0 - diffuseMapCoord);
        #else
            diffuseMap = ATLAS_TEXEL_FETCH(texture0, uv0);
        #endif

        // Water normals are generated procedurally now (calculateWaterNormalVector),
        // so the relief map is only needed for opaque PBR surfaces.
        #if defined(NORMAL_MAPPING_ENABLED) && defined(PBR_FEATURE_ENABLED)
            if(isWater < 0.5){
                #if defined(BLEND)
                    highp vec2 reliefMapCoord = diffuseMapCoord - vec2(0.0,  1.0 / (TEXTURE_ATLAS_DIMENSION.x * 2.0));
                #else
                    highp vec2 reliefMapCoord = diffuseMapCoord - vec2(0.0,  1.0 / (TEXTURE_ATLAS_DIMENSION.y * 2.0));
                #endif
                reliefMap = ATLAS_TEXEL_FETCH(texture0, uv0 - reliefMapCoord).rgb;
            }
        #endif

        #if defined(SPECULAR_MAPPING_ENABLED) && defined(PBR_FEATURE_ENABLED)
            // Top right texture - specular map
            highp vec2 rmeMapCoord = diffuseMapCoord - vec2(1.0 / (TEXTURE_ATLAS_DIMENSION.x * 2.0), 0.0);// 1.0/128.0
            rmeMap = clamp(ATLAS_TEXEL_FETCH(texture0, uv0 - rmeMapCoord),0.01, 1.0);
        #endif
    }
		

    void calculateMaterialProperties(out float metalness, out highp float roughness, out float shininess, highp vec4 rmeMap, float wetness){
        #if !defined(BLEND)
            #ifdef SPECULAR_MAPPING_ENABLED
                metalness = mix(pow(rmeMap.g, 2.0), 0.0, wetness);
                roughness = mix(pow(rmeMap.r, 3.46), 1.0, wetness);
                shininess = 512.0 * roughness;
            #else
                metalness = 0.0;
                roughness = 0.0;
                shininess = 0.0;
            #endif
        #else
            if(isWater >  0.9){
                metalness = 0.0;
                roughness = 1.0;
                shininess = 512.0;
            }else{
                #ifdef SPECULAR_MAPPING_ENABLED
                    metalness = mix(pow(rmeMap.g, 2.0), 0.0, wetness);
                    roughness = mix(pow(rmeMap.r, 2.0), 1.0, wetness);
                    shininess = 512.0 * roughness;
                #else
                    metalness = 0.0;
                    roughness = 0.0;
                    shininess = 0.0;
                #endif
            }
        #endif
    }

    void readLightMaps(out float srcPointLights, out float ambientOclusion, out float fakeShadow, vec2 uv1){
        srcPointLights = uv1.x;
        ambientOclusion = uv1.y;
        
        #ifdef  SHADOWS_ENABLED
            fakeShadow = min(pow(ambientOclusion * 1.15, SHADOW_SHARPNESS), 1.0);
        #else
            fakeShadow = 1.0;
        #endif
    }



/*
    highp vec2 parallax(highp vec2 uv, highp vec3 viewDir){
        
        highp vec3 n = vec3(0.0, 1.0, 0.0);
        highp vec3 t = vec3(0.0, 0.0, 1.0);
        highp vec3 b = vec3(1.0, 0.0, 0.0);

        highp mat3 tbn = transpose(mat3(t, b, n));

        viewDir = tbn * viewDir;

        highp float height_scale = 0.01;

        //highp float height = texture2D(texture0, uv).b;
        highp float height = 0.5;
        highp vec2 p = viewDir.xy / viewDir.z * (height * height_scale);

        //return uv;
        return uv - p;
    }
*/

	
	/////////////////////////////////////////////some experiments with TBN calculation ///////////////////////////////////////////////
	//highp vec2 duv1 = dFdx(uv0);
	//highp vec2 duv2 = dFdy(uv0);

	//highp vec3 dp2perp = cross(dp2, initNormalColor);
	//highp vec3 dp1perp = cross(initNormalColor, dp1);

	//highp vec3 T = normalize(dp2perp * duv1.x + dp1perp * duv2.x);
	//highp vec3 B = normalize(dp2perp * duv1.y + dp1perp * duv2.y);

	//highp float invmax = inversesqrt(max(dot(T,T), dot(B,B)));
	
	//highp mat3 tbn = mat3(T, B, initNormalColor);

	//reliefMap.rgb = reliefMap.rgb * 2.0 - 1.0;
	
	//normalColor.rgb = tbn * reliefMap.rgb;





	//highp vec3 q1 = dFdx(-position.xyz);
	//highp vec3 q2 = dFdy(-position.xyz);

	//highp vec2 st1 = dFdx(uv0);
	//highp vec2 st2 = dFdy(uv0);

	//highp vec3 T = normalize(q1*st2.t - q2*st1.t);
	//highp vec3 B = normalize(-q1*st2.s + q2*st1.s);

	//highp mat3 tbn = mat3(T, B, initNormalColor);

	//normalColor.rgb = normalColor.rgb * 2.0 - 1.0;

	//normalColor.rgb = reliefMap.rgb * tbn;



	//highp vec3 t = normalize(dFdx(position.xyz));
	//highp vec3 b = normalize(dFdy(position.xyz));
	//highp vec3 n = normalize(cross(t, b));

	//highp mat3 tbn = mat3(t, b, n);

	//normalColor.rgb = normalize(reliefMap.rgb * tbn);
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // _TEXTURE_MAPPING_GLSL
