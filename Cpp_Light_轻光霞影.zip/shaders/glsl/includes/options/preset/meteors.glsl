// Clear night shooting stars.
// A burst of METEOR_MIN_COUNT..METEOR_MAX_COUNT meteors is generated every
// METEOR_PERIOD seconds; each one gets its own start time, spawn point,
// direction, speed and trail length, all derived from hash21().
#define METEORS_ENABLED

#define METEOR_PERIOD 8.0 // seconds between two bursts
#define METEOR_MIN_COUNT 2 // meteors per burst (minimum)
#define METEOR_MAX_COUNT 7 // meteors per burst (maximum, also the loop bound)
#define METEOR_BRIGHTNESS 2.2 // overall brightness of a meteor
#define METEOR_ARC 26.0 // degrees a single meteor travels while it is visible
#define METEOR_TRAIL 18.0 // degrees of tail behind the head
#define METEOR_WIDTH 0.005 // angular half width of the streak (radians)
#define METEOR_NIGHT_LEVEL 0.35 // fog colour length below which it counts as night

// Spawn points stay random, but every meteor travels the same way.
// Change this vector to steer them (e.g. vec3(1.0, -0.2, 0.0) for +X and a little
// downwards). The vector is projected onto the sky tangent plane per meteor.
#define METEOR_DIRECTION vec3(-1.0, 0.0, 0.0)
