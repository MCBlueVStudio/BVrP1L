#define NORMAL_MAP_STRENGTH 1.0

// Water surface: procedural ripples (no texture atlas dependency)
#define WATER_NORMAL_MAP_STRENGTH 0.125 // ripple height, bigger = stronger distortion
#define WATER_WAVE_SCALE 1.0 // ripple frequency, bigger = smaller ripples
#define WATER_WAVE_SPEED 1.0 // ripple animation speed
#define WATER_SPECULAR_STRENGTH 0.35 // sun / torch highlight on water, 1.0 = as strong as stone

// Rain: how wet the ground gets and how the puddles look
#define PUDDLES_AMOUNT 1.15 // puddle coverage/intensity, bigger = more water
#define PUDDLES_SCALE 4.5 // puddle size in blocks, bigger = larger and rounder pools
#define PUDDLES_THRESHOLD 0.35 // noise cut off, lower = more puddles
#define PUDDLES_SOFTNESS 0.16 // edge width of a puddle, bigger = softer (rounder) edges
#define PUDDLES_MIN_SKY_LIGHT 0.9 // below this sky light the ground counts as covered (roof, cave, leaves)
#define PUDDLES_SEAM_FADE 8.0 // blocks around the 128 block world wrap where puddles fade out
#define RAIN_MIN_WETNESS 0.4 // base wetness of a rain soaked surface (0..1)
