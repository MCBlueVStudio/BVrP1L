#ifndef _METEORS_GLSL
#define _METEORS_GLSL

#include "includes/options/preset/meteors.glsl"

// Shooting stars for clear nights.
// Everything is generated from hash21(), so the meteors need no geometry, no
// extra draw call and no texture: one burst of METEOR_MIN_COUNT..MAX_COUNT
// meteors is spawned every METEOR_PERIOD seconds, each with its own start time,
// spawn point, direction, speed and trail length.

vec3 meteorDir(highp float azimuth, highp float elevation){
	highp float ce = cos(elevation);
	return vec3(ce * cos(azimuth), sin(elevation), ce * sin(azimuth));
}

// Distance based streak between 'tail' and 'head', evaluated in the tangent
// plane of the segment midpoint. No acos/slerp per pixel, just dots.
float meteorStreak(highp vec3 dir, highp vec3 head, highp vec3 tail){
	highp vec3 mid = normalize(head + tail);
	highp vec3 seg = head - tail;
	highp float halfLen = length(seg) * 0.5;
	seg = normalize(seg);

	highp vec3 rel = dir - mid * dot(dir, mid); // tangent offset from the midpoint
	highp float along = dot(rel, seg);
	highp float perp = length(rel - seg * along);

	highp float w = METEOR_WIDTH;
	float alongMask = 1.0 - smoothstep(halfLen - w, halfLen + w, abs(along));
	float perpMask = 1.0 - smoothstep(0.0, w, perp);

	// bright core at the head of the streak
	float headGlow = 1.0 - smoothstep(0.0, w * 3.0, length(dir - head));

	return alongMask * perpMask * 0.75 + headGlow;
}

vec3 meteorLayer(highp vec3 dir, float dayAmount, float isRain){
	if(dayAmount > METEOR_NIGHT_LEVEL || isRain > 0.1){
		return vec3(0.0);
	}

	highp float t = TIME;
	highp float burst = floor(t / METEOR_PERIOD);
	highp float burstTime = t - burst * METEOR_PERIOD;

	highp float count = float(METEOR_MIN_COUNT)
		+ floor(hash21(vec2(burst, 1.0)) * float(METEOR_MAX_COUNT - METEOR_MIN_COUNT + 1));
	count = clamp(count, float(METEOR_MIN_COUNT), float(METEOR_MAX_COUNT));

	vec3 total = vec3(0.0);

	for(int i = 0; i < METEOR_MAX_COUNT; i++){
		if(float(i) >= count){
			break;
		}

		highp float seed = float(i);
		highp float r0 = hash21(vec2(burst, seed + 2.0)); // start time
		highp float r1 = hash21(vec2(burst, seed + 9.0)); // life time

		highp float start = r0 * (METEOR_PERIOD - 2.0);
		highp float life = 0.55 + r1 * 0.75;
		highp float age = burstTime - start;

		if(age >= 0.0 && age <= life){
			highp float progress = age / life;

			highp float r2 = hash21(vec2(burst, seed + 16.0));
			highp float r3 = hash21(vec2(burst, seed + 23.0));
			highp float r5 = hash21(vec2(burst, seed + 37.0));

			// spawn point is random, but kept above the horizon
			highp vec3 startDir = meteorDir(r2 * 6.2831853, radians(mix(14.0, 62.0, r3)));

			// every meteor travels towards METEOR_DIRECTION: project that world
			// direction onto the tangent plane of the spawn point
			highp vec3 travelDir = normalize(METEOR_DIRECTION);
			highp vec3 moveDir = travelDir - startDir * dot(startDir, travelDir);
			highp float moveLen = length(moveDir);
			moveDir = moveLen > 0.001 ? moveDir / moveLen
			                          : normalize(cross(startDir, vec3(0.0, 1.0, 0.0)));

			highp float angle = progress * radians(METEOR_ARC);
			highp vec3 head = startDir * cos(angle) + moveDir * sin(angle);
			highp vec3 headMove = -startDir * sin(angle) + moveDir * cos(angle);

			highp float trail = radians(METEOR_TRAIL) * (0.6 + r5 * 0.8);
			highp vec3 tail = head * cos(trail) - headMove * sin(trail);

			float fade = smoothstep(0.0, 0.15, progress) * (1.0 - smoothstep(0.65, 1.0, progress));
			float brightness = METEOR_BRIGHTNESS * fade * (0.55 + r1 * 0.65);

			float streak = meteorStreak(dir, head, tail);

			// slightly blue white, like a real meteor
			total += vec3(0.82, 0.90, 1.0) * streak * brightness;
		}
	}

	return total;
}

#endif //_METEORS_GLSL
