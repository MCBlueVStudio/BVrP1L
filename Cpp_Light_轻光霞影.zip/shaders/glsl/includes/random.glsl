#ifndef _RANDOM_GLSL
#define _RANDOM_GLSL

#include "uniformPerFrameConstants.h"

// Upper limit for the cloud noise octaves.
// GLSL ES 1.00 requires loops to have a constant iteration count, so the
// octave loop below is written as a constant bounded for-loop with an early
// break instead of a while-loop (while-loops are rejected or unrolled badly
// by some OpenGL ES drivers).
#define MAX_CLOUD_OCTAVES 8

// ---------------------------------------------------------------------------
// Texture free value noise.
// The wetness / water effects used to read their noise from fixed cells of the
// terrain atlas, which depends on the atlas layout of the engine and produced
// hard, blocky patches on other builds. These helpers generate the same kind of
// noise procedurally, so the result is identical on every OpenGL engine and the
// puddles can be made as round and soft as we want.
// ---------------------------------------------------------------------------

// sin() free hash, no visible diagonal banding like the cloud hash below
float hash21(highp vec2 coord){
	highp vec2 p = fract(coord * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

// value noise with smoothstep interpolation (C1 continuous -> round blobs)
float noise21(highp vec2 coord){
	highp vec2 i = floor(coord);
	highp vec2 f = fract(coord);
	f = f * f * (3.0 - 2.0 * f);

	float a = hash21(i);
	float b = hash21(i + vec2(1.0, 0.0));
	float c = hash21(i + vec2(0.0, 1.0));
	float d = hash21(i + vec2(1.0, 1.0));

	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// two octaves are enough for puddles and stay cheap on mobile GPUs
float fbm21(highp vec2 coord){
	float value = 0.0;
	float norm = 0.0;
	float amp = 0.5;

	for(int i = 0; i < 2; i++){
		value += noise21(coord) * amp;
		norm += amp;
		coord = coord * 2.03 + vec2(11.3, 7.7);
		amp *= 0.5;
	}
	return value / norm;
}

float rand(highp vec2 coord){
    return fract(sin(dot(coord.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

//float rand(vec2 xy){
//       return fract(tan(distance(xy*1.61803398874989484820459, xy)*1.0)*xy.x);
//}

float step_random(highp vec2 coord){
    vec2 flooredCoord = floor(coord);
	return rand(flooredCoord);
}

float rand_bilinear(highp vec2 coord){

	vec2 flooredCoord = floor(coord);

	float leftTopSample = rand(flooredCoord);
	float righTopSample = rand(flooredCoord + vec2(0.0, 1.0));
	float leftBottomSample = rand(flooredCoord + vec2(1.0, 0.0));
	float rightBottomSample = rand(flooredCoord + vec2(1.0, 1.0));

	vec2 fractionalPart = coord - flooredCoord;

	float topRow = mix(leftTopSample, righTopSample, fractionalPart.y);
	float botRow = mix(leftBottomSample, rightBottomSample, fractionalPart.y);

	float result = mix(topRow, botRow, fractionalPart.x);

	return result;
}

float cloudsPerlin(int octaves, vec2 position){

	position = clamp(position, -64.0, 64.0);

	highp float time = TIME;
	float speed = 0.1;
	float scaleMultiplier = pow(2.0, float(octaves)); //  smaller scale - bigger noise
	float intensityMultiplier = 1.0;
	float resultDevider = 0.0;

	float noise = 0.0;

	for(int i = 0; i < MAX_CLOUD_OCTAVES; i++){
		if(i >= octaves){
			break;
		}
		noise += rand_bilinear(position * scaleMultiplier) * intensityMultiplier;
		resultDevider += intensityMultiplier;
		scaleMultiplier *= 0.5;
		intensityMultiplier *= 2.0;
	}

	noise += rand_bilinear(position + vec2(time * speed)) * intensityMultiplier;
	resultDevider += intensityMultiplier;

	return noise / resultDevider;

}

#endif // _RANDOM_GLSL
