#ifndef _HELPERS_GLSL
#define _HELPERS_GLSL

// dFdx/dFdy availability:
//  - desktop OpenGL: core since GLSL 1.10, always available
//  - GLSL ES 3.00 and newer: core, always available
//  - GLSL ES 1.00: only through GL_OES_standard_derivatives, which is enabled
//    at the top of renderchunk.fragment (the shader that includes this file)
#if defined(GL_ES) && __VERSION__ < 300 && !defined(GL_OES_standard_derivatives)
	#define DERIVATIVES_SUPPORTED 0
#else
	#define DERIVATIVES_SUPPORTED 1
#endif

highp vec3 calculateRawNormalVector(highp vec3 position){
#if DERIVATIVES_SUPPORTED
	highp vec3 dp1 = dFdx(position);
	highp vec3 dp2 = dFdy(position);

	return normalize(cross(dp1, dp2));
#else
	// Derivatives are not available on this OpenGL driver. The terrain vertex
	// format carries no normal attribute, so fall back to the direction of the
	// pixel: the shader still compiles and the lighting stays usable.
	return normalize(position);
#endif
}


float calculateFresnel(vec3 initialNormalVector, vec3 normalVector, vec3 viewDir, float isWater, float isRain, float wetness){
    float flatFresnel = min(1.0 - dot(initialNormalVector, viewDir), 1.0);
	float detailedFresnel = min(1.0 - dot(normalVector, viewDir), 1.0);

	detailedFresnel = pow(detailedFresnel, 3.0);
	flatFresnel = pow(flatFresnel, 6.0);

	detailedFresnel = mix(detailedFresnel, flatFresnel, flatFresnel * isWater);
	detailedFresnel = mix(detailedFresnel, flatFresnel, wetness * isRain * initialNormalVector.g * (1.0 - isWater));
	return clamp(detailedFresnel, 0.0, 1.0);
}

#endif // _HELPERS_GLSL
