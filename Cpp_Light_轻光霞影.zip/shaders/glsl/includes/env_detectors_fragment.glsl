#ifndef _ENV_DETECTORS_FRAGMENT_GLSL
#define _ENV_DETECTORS_FRAGMENT_GLSL

#include "includes/env_detectors.glsl"

// Texture based environment detectors.
// Only include this file from fragment shaders and only after the shader
// version header (fragmentVersion*.h) has been included, so that texture2D
// is mapped to texture() on GLSL ES 3.00 and stays texture2D on GLSL ES 1.00.

float detectHell(sampler2D texture1){
// Top left pixel is darker in overworld and brighter in the Nether
    float hellDetectionPixel = texture2D(texture1, vec2(0.0)).r;

	if (hellDetectionPixel > 0.15){
		return 1.0;
	}
    return 0.0;
}

float detectDay(sampler2D texture1){
	// Bottom left pixel becomes bluish at night. So we can get exact day time by calulating how much bigger b is than g
	vec3 dayTimeDetectionPixel = texture2D(texture1, vec2(0.0, 1.0)).rgb;
	float dayTime = dayTimeDetectionPixel.g / dayTimeDetectionPixel.b;
	return pow(dayTime, 5.0);
}

void detectEnvironment(out float isDay, out float isHell, out float isSunrize, sampler2D texture1){
	isDay = detectDay(texture1);
   	isHell = detectHell(texture1);
	isSunrize = detectSunRize();
}

#endif //_ENV_DETECTORS_FRAGMENT_GLSL
